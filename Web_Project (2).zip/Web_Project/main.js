const drugData = {
    aspirin: {
        name: "아스피린",
        use: "심혈관 질환 예방과 염증 완화에 사용됩니다. 주로 혈액 순환 개선과 발열 및 통증 완화에 효과적입니다.",
        overdose: "과다 복용 시 출혈, 귀울림, 간 손상 등의 위험이 있습니다. 위장 출혈을 일으킬 수 있기 때문에 사용 시 주의가 필요합니다.",
        interactions: ["warfarin", "omeprazole"],
        interactionEffect: "출혈 위험 증가",
    },
    statin: {
        name: "스타틴",
        use: "고지혈증을 치료하고, 동맥경화를 예방하는 데 도움을 줍니다. 심혈관 질환 예방에도 중요한 역할을 합니다.",
        overdose: "근육 통증과 약물의 과다 복용은 횡문근융해증을 유발할 수 있습니다. 장기적으로 신장에도 악영향을 미칠 수 있습니다.",
        interactions: ["furosemide"],
        interactionEffect: "근육 손상 악화",
    },
    metformin: {
        name: "메트포르민",
        use: "당뇨병 치료에 사용됩니다. 인슐린 저항성을 감소시키고 혈당 수치를 안정시키는 데 효과적입니다.",
        overdose: "과다 복용 시 저혈당, 위장 장애, 심한 경우 대사성 산증을 일으킬 수 있습니다. 즉시 의료 처치가 필요합니다.",
        interactions: ["warfarin", "furosemide"],
        interactionEffect: "혈당 조절 불안정",
    },
    amlodipine: {
        name: "암로디핀",
        use: "고혈압 및 협심증 치료에 사용됩니다. 혈관을 확장시켜 혈압을 낮추는 효과가 있습니다.",
        overdose: "과다 복용 시 저혈압, 두통, 어지러움, 심한 경우 심장 박동의 불규칙성 등의 증상이 나타날 수 있습니다.",
        interactions: ["statin"],
        interactionEffect: "혈압 강하 효과 과도",
    },
    furosemide: {
        name: "푸로세미드",
        use: "부종 및 고혈압을 치료하는 데 사용됩니다. 신장에 작용하여 체내의 불필요한 수분을 제거하는 효과가 있습니다.",
        overdose: "과다 복용 시 탈수, 전해질 불균형, 저혈압 등의 위험이 있습니다. 심한 경우 심장 기능에 영향을 줄 수 있습니다.",
        interactions: ["statin", "metformin"],
        interactionEffect: "근육 손상 및 혈당 불안정",
    },
    omeprazole: {
        name: "오메프라졸",
        use: "위장 질환인 위염, 위장 궤양, 역류성 식도염 등을 치료하는 데 사용됩니다. 위산을 억제하여 소화불량을 개선합니다.",
        overdose: "과다 복용 시 위장 불편감, 두통, 복통, 설사 등이 발생할 수 있습니다. 장기간 복용 시 뼈 건강에 영향을 미칠 수 있습니다.",
        interactions: ["aspirin"],
        interactionEffect: "위장 출혈 위험 증가",
    },
    warfarin: {
        name: "와파린",
        use: "혈액 응고를 방지하여 혈전 발생을 예방하는 데 사용됩니다. 심장 질환 및 뇌졸중 예방에 유용합니다.",
        overdose: "과다 복용 시 출혈이 발생할 수 있습니다. 특히, 뇌출혈과 같은 심각한 출혈이 발생할 수 있어 주의가 필요합니다.",
        interactions: ["aspirin", "omeprazole"],
        interactionEffect: "출혈 위험 증가",
    },
    levothyroxine: {
        name: "레보티록신",
        use: "갑상선 호르몬이 부족한 경우 이를 보충하기 위해 사용됩니다. 갑상선 기능 저하증을 치료하는 주요 약물입니다.",
        overdose: "과다 복용 시 갑상선 기능 과다로 인해 불안, 심박수 증가, 체중 감소 등의 증상이 나타날 수 있습니다.",
        interactions: ["warfarin"],
        interactionEffect: "출혈 위험 증가",
    },
    noxine: {
        name: "녹신",
        use: "항염증제 및 진통제로 사용되며, 류머티스 관절염과 같은 염증성 질환에 효과가 있습니다. 또한 근육통 완화에도 유용합니다.",
        overdose: "과다 복용 시 위장장애, 구토, 설사, 심한 경우 신장과 간에 손상을 줄 수 있습니다. 즉시 의료 기관을 방문해야 합니다.",
        interactions: ["warfarin"],
        interactionEffect: "출혈 위험 증가",
    },
    losartan: {
        name: "로사르탄",
        use: "고혈압 및 심부전 치료에 사용됩니다. 혈압을 낮추고 심장에 부담을 줄입니다.",
        overdose: "과다 복용 시 저혈압, 현기증, 구토 등의 증상이 나타날 수 있습니다.",
        interactions: ["lisinopril", "hydrochlorothiazide"],
        interactionEffect: "저혈압 위험 증가",
    },
    clopidogrel: {
        name: "클로피도그렐",
        use: "혈전 예방 및 심혈관 질환 예방에 사용됩니다. 주로 심장 우회 수술 후나 뇌졸중 예방에 사용됩니다.",
        overdose: "과다 복용 시 출혈 위험이 증가합니다.",
        interactions: ["aspirin", "warfarin"],
        interactionEffect: "출혈 위험 증가",
    },
    digoxin: {
        name: "디고신",
        use: "심부전 및 부정맥 치료에 사용됩니다. 심장의 펌프 기능을 개선하여 혈액 순환을 돕습니다.",
        overdose: "과다 복용 시 심박수 불규칙, 구토, 시각 장애 등이 발생할 수 있습니다.",
        interactions: ["amlodipine"],
        interactionEffect: "심박수 불규칙 위험 증가",
    },
    hydrochlorothiazide: {
        name: "하이드로클로로티아지드",
        use: "부종 및 고혈압 치료에 사용됩니다. 신장에서 나트륨을 배출시켜 수분을 제거하는 효과가 있습니다.",
        overdose: "과다 복용 시 저혈압, 전해질 불균형, 탈수 등의 증상이 나타날 수 있습니다.",
        interactions: ["losartan", "furosemide"],
        interactionEffect: "저혈압 및 전해질 불균형 위험 증가",
    },
    prednisone: {
        name: "프레드니손",
        use: "염증성 질환 및 면역계 질환의 치료에 사용됩니다. 주로 류머티즘, 알레르기 질환에 사용됩니다.",
        overdose: "과다 복용 시 체중 증가, 고혈당, 위장 장애 등의 증상이 나타날 수 있습니다.",
        interactions: ["warfarin"],
        interactionEffect: "출혈 위험 증가",
    },
    gabapentin: {
        name: "가바펜틴",
        use: "신경통 및 간질 치료에 사용됩니다. 주로 만성 신경통, 당뇨병성 신경병증에 사용됩니다.",
        overdose: "과다 복용 시 졸림, 어지러움, 언어 장애 등의 증상이 발생할 수 있습니다.",
        interactions: ["citalopram"],
        interactionEffect: "졸림 및 어지러움 증가",
    },
    citalopram: {
        name: "시탈로프람",
        use: "우울증 치료에 사용됩니다. 선택적 세로토닌 재흡수 억제제(SSRI)로서 우울증 및 불안 장애에 효과적입니다.",
        overdose: "과다 복용 시 세로토닌 증후군, 심장 부정맥 등의 위험이 있습니다.",
        interactions: ["gabapentin", "warfarin"],
        interactionEffect: "졸림 및 출혈 위험 증가",
    },

};

// 상세 페이지로 이동
function navigateToDetail(drugId) {
    const drug = drugData[drugId];
    if (!drug) return;

    const detailHTML = `
        <div>
            <button class="back-button" onclick="goBack()">뒤로가기</button>
            <h2 class="drug-detail-title">${drug.name}</h2>
            <p class="drug-detail-text"><strong>사용 목적:</strong> ${drug.use}</p>
            <p class="drug-detail-text"><strong>과복용 부작용:</strong> ${drug.overdose}</p>
            <h3 class="drug-detail-text">다른 약물 상호작용 확인</h3>
            <div id="interaction-grid" class="drug-detail-text">${renderInteractionOptions(drugId)}</div>
        </div>
    `;

    document.body.innerHTML = detailHTML;
}


// 뒤로가기 기능
function goBack() {
    window.history.back(); // 이전 페이지로 돌아가기
}

// 상호작용 옵션 표시
function renderInteractionOptions(currentDrugId) {
    return Object.keys(drugData)
        .filter((id) => id !== currentDrugId)
        .map(
            (id) => `
            <div class="interaction-item" onclick="checkInteraction('${currentDrugId}', '${id}')">
                ${drugData[id].name}
            </div>
        `
        )
        .join("");
}

// 상호작용 확인
function checkInteraction(drug1Id, drug2Id) {
    const drug1 = drugData[drug1Id];
    const drug2 = drugData[drug2Id];
    const interaction =
        drug1.interactions.includes(drug2Id) ||
        drug2.interactions.includes(drug1Id);

    const result = interaction
        ? `상호작용: ${drug1.interactionEffect}`
        : "상호작용 없음.";

    alert(result);
}
