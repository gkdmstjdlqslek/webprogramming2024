const todoForm = document.getElementById('todo-form'); // 폼 요소
const todoInput = document.getElementById('todo-input'); // 입력 필드
const todoList = document.getElementById('todo-list'); // 할 일 목록 UL 요소

// 폼 제출 이벤트 리스너
todoForm.addEventListener('submit', function(event) {
    event.preventDefault(); // 폼의 기본 동작 방지
    const todoText = todoInput.value.trim(); // 입력된 값을 가져와 공백 제거

    if (todoText !== '') { // 입력된 값이 비어 있지 않으면 실행
        // 새로운 리스트 아이템 요소 생성
        const todoItem = document.createElement('li');
        todoItem.textContent = todoText; // 리스트 아이템에 입력된 텍스트 추가

        // 리스트에 아이템 추가
        todoList.appendChild(todoItem);

        // 입력 필드 초기화
        todoInput.value = '';
    }
});
